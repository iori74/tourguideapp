package com.example.tourguideapp;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class InfosFragment extends Fragment {


    public InfosFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_list_industries, container, false);


        ArrayList<Guide> guide = new ArrayList<Guide>();
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.ARKEMA_FRANCE1,
                R.string.arkemalocation));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.ART_EMBALLAGES1,
                R.string.art_emballages_location));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.SOCIETE_DE_NETTOIEMENT1,
                R.string.cleaning_society_location));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.CHANTIER_NAVAL_MARSEILLE1,
                R.string.Marseille_Shipyard_Location));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.ROBINETERRIE_INDUSTRIE1,
                R.string.sri_location));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.PROVENCE1,
                R.string.provence_location));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.ENTREPRISE_BRONZO1,
                R.string.bronzo_location));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.EUROLINKS1,
                R.string.eurolinks_location));
        guide.add(new Guide(R.drawable.alloga_france_9,R.string.ALLOGA_FRANCE1,
                R.string.alloga_france_location));

        GroupListAdapter2 adapter = new GroupListAdapter2(getActivity(), guide);

        ListView recyclerView = rootView.findViewById(R.id.recycler);
        recyclerView.setAdapter(adapter);


        return rootView;
    }
}