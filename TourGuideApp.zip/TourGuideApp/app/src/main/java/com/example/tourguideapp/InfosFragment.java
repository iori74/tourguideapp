package com.example.tourguideapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

public class InfosFragment extends Fragment {


    public InfosFragment() {
        // Required empty public constructor
    }



    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View rootView = inflater.inflate(R.layout.fragment_list_industries, container, false);


        ArrayList<Guide> guide = new ArrayList<Guide>();
        guide.add(new Guide(R.string.ARKEMA_FRANCE1));
        guide.add(new Guide(R.string.ART_EMBALLAGES1));
        guide.add(new Guide(R.string.SOCIETE_DE_NETTOIEMENT1));
        guide.add(new Guide(R.string.CHANTIER_NAVAL_MARSEILLE1));
        guide.add(new Guide(R.string.ROBINETERRIE_INDUSTRIE1));
        guide.add(new Guide(R.string.PROVENCE1));
        guide.add(new Guide(R.string.ENTREPRISE_BRONZO1));
        guide.add(new Guide(R.string.EUROLINKS1));
        guide.add(new Guide(R.string.ALLOGA_FRANCE1));

        GroupListAdapter adapter = new GroupListAdapter(getActivity(), guide);

        ListView recyclerView = (ListView) rootView.findViewById(R.id.recycler);
        recyclerView.setAdapter(adapter);
        return rootView;
    }
}