package com.example.tourguideapp;

public class Guide {
    private final int mList;


    public Guide(int list) {
        mList = list;
    }

    public int getIndustriesList(){
        return  mList;
    }


}
