package com.example.tourguideapp;

public class Guide {
    private final int mList;
    private final int mImageList;
    private final int mLocationMap;

    public Guide(int list) {
        mList = list;
        mImageList = 0;
        mLocationMap = 0;
    }
    public Guide(int imageList,int list,int locationMap){
        mImageList = imageList;
        mList = list;
        mLocationMap = locationMap;
    }

    public int getIndustriesList(){
        return  mList;
    }

    public int getImageList() {
        return mImageList;
    }

    public int getLocationMap(){
        return mLocationMap;
    }
}
