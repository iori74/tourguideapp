package com.example.tourguideapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView industries = (ImageView) findViewById(R.id.industries);
        industries.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick  (View v) {
                Intent industries = new Intent(MainActivity.this, InfosActivity.class);
                startActivity(industries);
            }
        });
        TextView textView = (TextView) findViewById(R.id.textView2);
        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent map = new Intent(MainActivity.this, LocationMap.class);
                startActivity(map);
            }
        });
    }
}